import "./globals.css";



export const metadata = {
  title: "Fizzero",
  description: "Dashboard UI With Next js & Typescript + MUI",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  );
}


// className={`${geistSans.variable} ${geistMono.variable} antialiased`} 